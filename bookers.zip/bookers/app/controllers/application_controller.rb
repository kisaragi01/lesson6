class ApplicationController < ActionController::Base
    def edit
        @book = Book.find(params[:id])
    end
end
